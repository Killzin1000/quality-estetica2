import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { StockForm } from './components/StockForm';
import { PatientProfile } from './components/PatientProfile';
import { Dashboard } from './components/Dashboard';
import { Financials } from './components/Financials';
import { Login } from './components/Login';
import { ViewState, Product, Patient } from './types';
import { Menu } from 'lucide-react';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentView, setCurrentView] = useState<ViewState>('dashboard');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Global State (Mocking Supabase)
  const [products, setProducts] = useState<Product[]>([
    {
      id: '1',
      name: 'Toxina Botulínica Tipo A',
      brand: 'Botox',
      lotNumber: 'BX202399',
      expiryDate: '2023-11-15', // Expiring soon for demo
      costPrice: 800,
      salePrice: 1500,
      supplier: 'Allergan',
      quantity: 3 // Low stock for demo
    },
    {
      id: '2',
      name: 'Ácido Hialurônico 1ml',
      brand: 'Restylane',
      lotNumber: 'RS88221',
      expiryDate: '2024-06-20',
      costPrice: 600,
      salePrice: 1200,
      supplier: 'Galderma',
      quantity: 10
    }
  ]);

  const [activePatient] = useState<Patient>({
    id: '1',
    name: 'Ana Carolina Silva',
    age: 34,
    phone: '(11) 99876-5432',
    photoUrl: 'https://picsum.photos/200'
  });

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    console.log('[Quality-Log] Usuário desconectado');
    setIsAuthenticated(false);
    setCurrentView('dashboard'); // Reset view on logout
  };

  const handleAddProduct = (product: Product) => {
    setProducts(prev => [...prev, product]);
    console.log('[Quality-Log] Produto salvo no estado global:', product.name);
  };

  const handleDeleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
    console.log('[Quality-Log] Produto removido:', id);
  };

  const renderContent = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard products={products} />;
      case 'stock':
        return <StockForm products={products} onAddProduct={handleAddProduct} onDeleteProduct={handleDeleteProduct} />;
      case 'patients':
        return <PatientProfile patient={activePatient} />;
      case 'financial':
        return <Financials />;
      case 'calendar':
        return (
          <div className="flex flex-col items-center justify-center h-[50vh] text-slate-400">
             <div className="p-6 bg-white rounded-2xl shadow-sm border border-slate-100 text-center">
                <p className="text-lg font-medium text-slate-600">Calendário Interativo</p>
                <p className="text-sm mt-2">Funcionalidade de agendamento em desenvolvimento.</p>
             </div>
          </div>
        );
      default:
        return <div>View not found</div>;
    }
  };

  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <Sidebar 
        currentView={currentView} 
        onNavigate={setCurrentView} 
        isMobileOpen={isMobileSidebarOpen}
        setIsMobileOpen={setIsMobileSidebarOpen}
        onLogout={handleLogout}
      />

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        {/* Mobile Header */}
        <div className="md:hidden bg-white border-b border-slate-200 p-4 flex items-center justify-between z-10">
          <div className="flex items-center gap-2">
             <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white font-bold">Q</div>
             <span className="font-bold text-slate-800">Quality</span>
          </div>
          <button onClick={() => setIsMobileSidebarOpen(true)} className="text-slate-600">
            <Menu size={24} />
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8">
            <header className="mb-8 hidden md:block">
                <h1 className="text-2xl font-bold text-slate-800 capitalize">
                    {currentView === 'stock' ? 'Gestão de Estoque' : 
                     currentView === 'patients' ? 'Prontuário do Paciente' : 
                     currentView}
                </h1>
                <p className="text-slate-500 text-sm mt-1">Bem-vindo ao sistema Quality Estética.</p>
            </header>
            
            {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default App;