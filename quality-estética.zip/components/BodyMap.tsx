import React, { useState, useRef } from 'react';
import { BodyMarker } from '../types';
import { X, MapPin } from 'lucide-react';

interface BodyMapProps {
  markers: BodyMarker[];
  onAddMarker: (marker: BodyMarker) => void;
  onRemoveMarker: (id: string) => void;
}

export const BodyMap: React.FC<BodyMapProps> = ({ markers, onAddMarker, onRemoveMarker }) => {
  const [view, setView] = useState<'front' | 'back'>('front');
  const [tempMarker, setTempMarker] = useState<{x: number, y: number} | null>(null);
  const [note, setNote] = useState('');
  const svgRef = useRef<SVGSVGElement>(null);

  const handleSvgClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (tempMarker) return; // Prevent clicking while adding a note
    
    if (svgRef.current) {
      const rect = svgRef.current.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;
      
      setTempMarker({ x, y });
    }
  };

  const confirmMarker = () => {
    if (tempMarker && note) {
      const newMarker: BodyMarker = {
        id: crypto.randomUUID(),
        x: tempMarker.x,
        y: tempMarker.y,
        note,
        side: view
      };
      
      console.log('[Quality-Log] Marcador adicionado ao mapa corporal:', newMarker);
      onAddMarker(newMarker);
      setTempMarker(null);
      setNote('');
    }
  };

  const filteredMarkers = markers.filter(m => m.side === view);

  return (
    <div className="flex flex-col md:flex-row gap-6">
      {/* Controls */}
      <div className="w-full md:w-64 flex flex-col gap-4">
        <div className="bg-slate-100 p-1 rounded-lg flex">
          <button 
            onClick={() => setView('front')}
            className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${view === 'front' ? 'bg-white shadow text-primary' : 'text-slate-500'}`}
          >
            Frente
          </button>
          <button 
            onClick={() => setView('back')}
            className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${view === 'back' ? 'bg-white shadow text-primary' : 'text-slate-500'}`}
          >
            Costas
          </button>
        </div>

        <div className="bg-blue-50 border border-blue-100 p-4 rounded-xl text-sm text-blue-700">
            <p><strong>Instrução:</strong> Clique na silhueta para adicionar um ponto de procedimento.</p>
        </div>

        {/* List of points */}
        <div className="flex-1 overflow-y-auto max-h-[400px] space-y-2">
            <h3 className="font-semibold text-slate-700 mb-2">Pontos Marcados ({view})</h3>
            {filteredMarkers.length === 0 && <p className="text-slate-400 text-sm">Nenhum ponto marcado.</p>}
            {filteredMarkers.map(marker => (
                <div key={marker.id} className="bg-white p-3 rounded-lg border border-slate-100 shadow-sm flex justify-between items-start group">
                    <div className="flex gap-2">
                        <MapPin size={16} className="text-primary mt-1" />
                        <p className="text-sm text-slate-600">{marker.note}</p>
                    </div>
                    <button 
                        onClick={() => onRemoveMarker(marker.id)}
                        className="text-slate-300 hover:text-red-500"
                    >
                        <X size={14} />
                    </button>
                </div>
            ))}
        </div>
      </div>

      {/* Interactive Map */}
      <div className="flex-1 bg-white border border-slate-200 rounded-2xl p-4 flex justify-center relative overflow-hidden h-[600px]">
        <svg 
            ref={svgRef}
            viewBox="0 0 200 500" 
            className="h-full w-auto cursor-crosshair drop-shadow-xl"
            onClick={handleSvgClick}
        >
            <defs>
                <linearGradient id="bodyGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" style={{stopColor: '#f1f5f9', stopOpacity: 1}} />
                    <stop offset="50%" style={{stopColor: '#e2e8f0', stopOpacity: 1}} />
                    <stop offset="100%" style={{stopColor: '#f1f5f9', stopOpacity: 1}} />
                </linearGradient>
            </defs>
            {/* Simplified Silhouette Path */}
            {view === 'front' ? (
                <path 
                    d="M100,20 C85,20 75,35 75,50 C75,65 80,75 80,75 C70,80 50,85 45,110 L40,200 L55,200 C55,200 55,250 60,250 C60,250 60,350 65,350 L75,480 L95,480 L98,380 L102,380 L105,480 L125,480 L135,350 C140,350 140,250 140,250 C145,250 145,200 145,200 L160,200 L155,110 C150,85 130,80 120,75 C120,75 125,65 125,50 C125,35 115,20 100,20 Z" 
                    fill="url(#bodyGradient)" 
                    stroke="#94a3b8" 
                    strokeWidth="1"
                />
            ) : (
                <path 
                    d="M100,20 C85,20 75,35 75,50 C75,65 80,75 80,75 C65,80 50,85 45,110 L40,200 L55,200 C55,200 55,250 60,250 C60,250 60,350 65,350 L75,480 L95,480 L98,380 L102,380 L105,480 L125,480 L135,350 C140,350 140,250 140,250 C145,250 145,200 145,200 L160,200 L155,110 C150,85 135,80 120,75 C120,75 125,65 125,50 C125,35 115,20 100,20 Z" 
                    fill="url(#bodyGradient)" 
                    stroke="#94a3b8" 
                    strokeWidth="1"
                />
            )}

            {/* Render Existing Markers */}
            {filteredMarkers.map(marker => (
                <circle 
                    key={marker.id}
                    cx={marker.x}
                    cy={marker.y}
                    r="3"
                    className="fill-primary stroke-white stroke-[0.5] hover:r-4 transition-all"
                />
            ))}

            {/* Render Temp Marker */}
            {tempMarker && (
                <circle 
                    cx={tempMarker.x}
                    cy={tempMarker.y}
                    r="4"
                    className="fill-red-500 animate-pulse"
                />
            )}
        </svg>

        {/* Input Popover for Note */}
        {tempMarker && (
            <div 
                className="absolute bg-white p-3 rounded-xl shadow-xl border border-slate-200 w-64 z-10"
                style={{ 
                    left: `${Math.min(Math.max(tempMarker.x, 10), 90)}%`, 
                    top: `${Math.min(Math.max(tempMarker.y, 10), 90)}%`,
                    transform: 'translate(-50%, -120%)'
                }}
            >
                <div className="flex justify-between items-center mb-2">
                    <span className="text-xs font-bold text-slate-700">Adicionar Nota</span>
                    <button onClick={() => setTempMarker(null)}><X size={14} className="text-slate-400 hover:text-red-500"/></button>
                </div>
                <textarea
                    autoFocus
                    className="w-full text-sm border border-slate-200 rounded p-2 mb-2 outline-none focus:border-primary"
                    rows={2}
                    placeholder="Ex: 5ml preenchedor"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                />
                <button 
                    onClick={confirmMarker}
                    disabled={!note}
                    className="w-full bg-primary text-white text-xs py-1.5 rounded font-medium disabled:opacity-50 hover:bg-pink-700"
                >
                    Salvar Ponto
                </button>
            </div>
        )}
      </div>
    </div>
  );
};