import React from 'react';
import { FinancialRecord } from '../types';
import { ArrowUpCircle, ArrowDownCircle, DollarSign } from 'lucide-react';

export const Financials: React.FC = () => {
    // Mock Data
    const records: FinancialRecord[] = [
        { id: '1', description: 'Aplicação Botox - Ana Silva', amount: 1500, type: 'income', date: '2023-10-25', category: 'Serviço' },
        { id: '2', description: 'Compra de Insumos', amount: 450, type: 'expense', date: '2023-10-24', category: 'Estoque' },
        { id: '3', description: 'Limpeza de Pele - Maria J.', amount: 250, type: 'income', date: '2023-10-24', category: 'Serviço' },
        { id: '4', description: 'Aluguel Sala', amount: 2000, type: 'expense', date: '2023-10-01', category: 'Fixo' },
    ];

    const totalIncome = records.filter(r => r.type === 'income').reduce((acc, curr) => acc + curr.amount, 0);
    const totalExpense = records.filter(r => r.type === 'expense').reduce((acc, curr) => acc + curr.amount, 0);
    const balance = totalIncome - totalExpense;

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                    <div className="flex items-center gap-3 mb-2">
                        <ArrowUpCircle className="text-green-500" />
                        <span className="text-sm font-medium text-slate-500">Entradas</span>
                    </div>
                    <p className="text-2xl font-bold text-slate-800">R$ {totalIncome.toFixed(2)}</p>
                </div>
                 <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                    <div className="flex items-center gap-3 mb-2">
                        <ArrowDownCircle className="text-red-500" />
                        <span className="text-sm font-medium text-slate-500">Saídas</span>
                    </div>
                    <p className="text-2xl font-bold text-slate-800">R$ {totalExpense.toFixed(2)}</p>
                </div>
                 <div className="bg-gradient-to-br from-primary to-pink-700 p-6 rounded-2xl shadow-lg text-white">
                    <div className="flex items-center gap-3 mb-2">
                        <DollarSign className="text-white/80" />
                        <span className="text-sm font-medium text-white/80">Saldo Atual</span>
                    </div>
                    <p className="text-3xl font-bold">R$ {balance.toFixed(2)}</p>
                </div>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="p-6 border-b border-slate-100">
                    <h3 className="font-bold text-slate-800">Fluxo de Caixa Recente</h3>
                </div>
                <table className="w-full text-left">
                    <thead className="bg-slate-50">
                        <tr>
                            <th className="p-4 text-xs font-semibold text-slate-500 uppercase">Data</th>
                            <th className="p-4 text-xs font-semibold text-slate-500 uppercase">Descrição</th>
                            <th className="p-4 text-xs font-semibold text-slate-500 uppercase">Categoria</th>
                            <th className="p-4 text-xs font-semibold text-slate-500 uppercase text-right">Valor</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {records.map(record => (
                            <tr key={record.id} className="hover:bg-slate-50">
                                <td className="p-4 text-sm text-slate-600">{new Date(record.date).toLocaleDateString()}</td>
                                <td className="p-4 text-sm font-medium text-slate-800">{record.description}</td>
                                <td className="p-4 text-sm text-slate-500">
                                    <span className="px-2 py-1 bg-slate-100 rounded-full text-xs">{record.category}</span>
                                </td>
                                <td className={`p-4 text-sm font-bold text-right ${record.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                                    {record.type === 'income' ? '+' : '-'} R$ {record.amount.toFixed(2)}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};