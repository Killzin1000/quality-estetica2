import React, { useState } from 'react';
import { Lock, User } from 'lucide-react';

interface LoginProps {
  onLogin: () => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Mock authentication check
    // In a real Supabase app, this would use supabase.auth.signInWithPassword
    if (email === 'admin@quality.com' && password === 'admin123') {
      console.log('[Quality-Log] Login realizado com sucesso para:', email);
      onLogin();
    } else {
      console.log('[Quality-Log] Tentativa de login falhou para:', email);
      setError('Credenciais inválidas. Tente admin@quality.com / admin123');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="bg-white p-8 rounded-3xl shadow-xl border border-slate-100 w-full max-w-md relative overflow-hidden">
        {/* Decorative background element */}
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-primary to-pink-400"></div>
        
        <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center text-white font-bold text-2xl mb-4 shadow-lg shadow-pink-200 transform rotate-3">
                Q
            </div>
            <h1 className="text-2xl font-bold text-slate-800">Quality Estética</h1>
            <p className="text-slate-500 text-sm mt-1">Gestão inteligente para sua clínica</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
            <div>
                <label className="block text-sm font-medium text-slate-700 mb-1 ml-1">Email de Acesso</label>
                <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                        type="email" 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-slate-700 bg-slate-50 focus:bg-white"
                        placeholder="admin@quality.com"
                    />
                </div>
            </div>
            
            <div>
                <label className="block text-sm font-medium text-slate-700 mb-1 ml-1">Senha</label>
                <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                        type="password" 
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-slate-700 bg-slate-50 focus:bg-white"
                        placeholder="admin123"
                    />
                </div>
            </div>

            {error && (
                <div className="p-3 bg-red-50 text-red-600 text-sm rounded-xl border border-red-100 flex items-center gap-2 animate-pulse">
                    <span className="w-1.5 h-1.5 bg-red-500 rounded-full"></span>
                    {error}
                </div>
            )}

            <button 
                type="submit"
                className="w-full bg-primary text-white font-bold py-3.5 rounded-xl hover:bg-pink-700 transition-all shadow-lg shadow-pink-200 active:scale-[0.98] flex items-center justify-center gap-2"
            >
                Entrar no Sistema
            </button>
        </form>

        <div className="mt-8 text-center">
            <p className="text-xs text-slate-400">
                &copy; {new Date().getFullYear()} Quality Estética System
            </p>
        </div>
      </div>
    </div>
  );
};