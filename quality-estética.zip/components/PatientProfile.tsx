import React, { useState } from 'react';
import { Patient, AnamnesisField, BodyMarker, PatientPayment, Appointment } from '../types';
import { BodyMap } from './BodyMap';
import { Camera, FileText, Activity, Image as ImageIcon, CheckCircle, Upload, CreditCard, Calendar, Download } from 'lucide-react';

interface PatientProfileProps {
  patient: Patient;
}

export const PatientProfile: React.FC<PatientProfileProps> = ({ patient }) => {
  const [activeTab, setActiveTab] = useState<'info' | 'anamnesis' | 'bodymap' | 'photos' | 'payments'>('info');
  
  // Existing States
  const [anamnesisData, setAnamnesisData] = useState<AnamnesisField[]>([
    { id: '1', label: 'Possui alergias?', type: 'boolean', value: false },
    { id: '2', label: 'Quais alergias?', type: 'text', value: '' },
    { id: '3', label: 'Tipo de Pele', type: 'select', options: ['Seca', 'Oleosa', 'Mista', 'Normal'], value: 'Mista' },
    { id: '4', label: 'Uso de medicamentos?', type: 'text', value: '' },
  ]);
  const [markers, setMarkers] = useState<BodyMarker[]>([]);
  const [photos, setPhotos] = useState<{id: string, url: string, type: 'before' | 'after'}[]>([]);

  // New States for Payments Tab
  const [appointments] = useState<Appointment[]>([
    { id: '1', date: '2023-10-25', procedure: 'Toxina Botulínica', status: 'completed' },
    { id: '2', date: '2023-11-15', procedure: 'Retorno', status: 'scheduled' },
    { id: '3', date: '2023-09-10', procedure: 'Limpeza de Pele', status: 'completed' },
  ]);

  const [payments, setPayments] = useState<PatientPayment[]>([
    { id: '1', date: '2023-09-10', procedure: 'Limpeza de Pele', amount: 250.00 }
  ]);

  const [newPayment, setNewPayment] = useState<Partial<PatientPayment>>({
    date: new Date().toISOString().split('T')[0],
    procedure: '',
    amount: 0,
  });
  const [tempReceipt, setTempReceipt] = useState<string | null>(null);

  // Body Map Handlers
  const handleAddMarker = (marker: BodyMarker) => {
    setMarkers(prev => [...prev, marker]);
  };
  
  const handleRemoveMarker = (id: string) => {
    setMarkers(prev => prev.filter(m => m.id !== id));
  };

  // Photo Handler
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'before' | 'after') => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const url = URL.createObjectURL(file);
      const newPhoto = { id: crypto.randomUUID(), url, type };
      
      console.log(`[Quality-Log] Nova foto anexada (${type}):`, newPhoto);
      setPhotos(prev => [...prev, newPhoto]);
    }
  };

  // Payment Handlers
  const handleReceiptUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const url = URL.createObjectURL(file);
      setTempReceipt(url);
      console.log('[Quality-Log] Comprovante de pagamento selecionado');
    }
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPayment.procedure || !newPayment.amount) return;

    const paymentToAdd: PatientPayment = {
      id: crypto.randomUUID(),
      date: newPayment.date || new Date().toISOString().split('T')[0],
      procedure: newPayment.procedure,
      amount: Number(newPayment.amount),
      receiptUrl: tempReceipt || undefined
    };

    setPayments(prev => [paymentToAdd, ...prev]);
    console.log('[Quality-Log] Novo pagamento registrado:', paymentToAdd);

    // Reset form
    setNewPayment({
      date: new Date().toISOString().split('T')[0],
      procedure: '',
      amount: 0,
    });
    setTempReceipt(null);
  };

  const tabs = [
    { id: 'info', label: 'Dados', icon: Activity },
    { id: 'anamnesis', label: 'Anamnese', icon: FileText },
    { id: 'bodymap', label: 'Mapa Corporal', icon: Activity },
    { id: 'photos', label: 'Fotos', icon: ImageIcon },
    { id: 'payments', label: 'Financeiro', icon: CreditCard },
  ];

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 min-h-[600px] flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-slate-100 flex items-center justify-between">
        <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 font-bold text-2xl overflow-hidden">
                {patient.photoUrl ? <img src={patient.photoUrl} alt={patient.name} className="w-full h-full object-cover"/> : patient.name.charAt(0)}
            </div>
            <div>
                <h2 className="text-2xl font-bold text-slate-800">{patient.name}</h2>
                <p className="text-slate-500">{patient.age} anos • {patient.phone}</p>
            </div>
        </div>
        <div className="flex gap-2">
            <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold uppercase tracking-wide">Ativo</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-100 px-6 overflow-x-auto">
        {tabs.map(tab => {
            const Icon = tab.icon;
            return (
                <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`
                        flex items-center gap-2 px-6 py-4 text-sm font-medium border-b-2 transition-colors whitespace-nowrap
                        ${activeTab === tab.id ? 'border-primary text-primary' : 'border-transparent text-slate-500 hover:text-slate-700'}
                    `}
                >
                    <Icon size={16} />
                    {tab.label}
                </button>
            )
        })}
      </div>

      {/* Content */}
      <div className="p-6 flex-1">
        {activeTab === 'info' && (
            <div className="space-y-4">
                <h3 className="text-lg font-semibold text-slate-800">Dados Cadastrais</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-slate-600">
                    <div className="p-4 bg-slate-50 rounded-lg">
                        <span className="text-xs uppercase text-slate-400 font-bold block mb-1">Nome Completo</span>
                        {patient.name}
                    </div>
                     <div className="p-4 bg-slate-50 rounded-lg">
                        <span className="text-xs uppercase text-slate-400 font-bold block mb-1">Idade</span>
                        {patient.age}
                    </div>
                     <div className="p-4 bg-slate-50 rounded-lg">
                        <span className="text-xs uppercase text-slate-400 font-bold block mb-1">Telefone</span>
                        {patient.phone}
                    </div>
                </div>
            </div>
        )}

        {activeTab === 'anamnesis' && (
             <div className="space-y-6 max-w-3xl mx-auto">
                <h3 className="text-lg font-semibold text-slate-800 mb-4">Ficha de Anamnese</h3>
                <div className="space-y-4">
                    {anamnesisData.map(field => (
                        <div key={field.id} className="bg-slate-50 p-4 rounded-lg border border-slate-100">
                            <label className="block text-sm font-medium text-slate-700 mb-2">{field.label}</label>
                            {field.type === 'text' && (
                                <input type="text" className="w-full p-2 border border-slate-200 rounded bg-white" defaultValue={field.value as string} />
                            )}
                            {field.type === 'boolean' && (
                                <div className="flex gap-4">
                                    <label className="flex items-center gap-2 cursor-pointer">
                                        <input type="radio" name={field.id} defaultChecked={field.value === true} /> Sim
                                    </label>
                                    <label className="flex items-center gap-2 cursor-pointer">
                                        <input type="radio" name={field.id} defaultChecked={field.value === false} /> Não
                                    </label>
                                </div>
                            )}
                            {field.type === 'select' && field.options && (
                                <select className="w-full p-2 border border-slate-200 rounded bg-white" defaultValue={field.value as string}>
                                    {field.options.map(opt => <option key={opt}>{opt}</option>)}
                                </select>
                            )}
                        </div>
                    ))}
                </div>

                {/* Digital Signature Mock */}
                <div className="mt-8 border-t border-slate-200 pt-6">
                    <label className="block text-sm font-medium text-slate-700 mb-2">Assinatura do Cliente</label>
                    <div className="h-32 bg-slate-50 border-2 border-dashed border-slate-300 rounded-lg flex items-center justify-center text-slate-400 cursor-crosshair hover:bg-slate-100 transition-colors">
                        Clique para assinar digitalmente
                    </div>
                </div>
                
                 {/* Attachment */}
                <div className="mt-4">
                    <label className="block text-sm font-medium text-slate-700 mb-2">Anexar Anamnese Física</label>
                    <div className="flex gap-2">
                        <label className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-300 rounded-lg cursor-pointer hover:bg-slate-50">
                            <Camera size={18} />
                            <span className="text-sm">Tirar Foto</span>
                            <input type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => handlePhotoUpload(e, 'before')}/>
                        </label>
                        <label className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-300 rounded-lg cursor-pointer hover:bg-slate-50">
                            <Upload size={18} />
                            <span className="text-sm">Upload Arquivo</span>
                            <input type="file" accept=".pdf,image/*" className="hidden" />
                        </label>
                    </div>
                </div>
            </div>
        )}

        {activeTab === 'bodymap' && (
            <BodyMap 
                markers={markers} 
                onAddMarker={handleAddMarker} 
                onRemoveMarker={handleRemoveMarker} 
            />
        )}

        {activeTab === 'photos' && (
            <div className="space-y-6">
                <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold text-slate-800">Galeria Antes & Depois</h3>
                    <div className="flex gap-2">
                         <label className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg cursor-pointer hover:bg-pink-700 shadow-sm transition-all">
                            <Camera size={18} />
                            <span className="text-sm font-medium">Nova Foto</span>
                            <input type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => handlePhotoUpload(e, 'after')} />
                        </label>
                    </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {photos.length === 0 && (
                        <div className="col-span-full py-12 text-center text-slate-400 border-2 border-dashed border-slate-200 rounded-xl">
                            <ImageIcon size={48} className="mx-auto mb-2 opacity-50" />
                            <p>Nenhuma foto registrada para este paciente.</p>
                        </div>
                    )}
                    {photos.map(photo => (
                        <div key={photo.id} className="relative group rounded-xl overflow-hidden shadow-sm aspect-square bg-slate-100">
                            <img src={photo.url} alt={photo.type} className="w-full h-full object-cover" />
                            <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white p-2 text-xs font-bold uppercase backdrop-blur-sm">
                                {photo.type === 'before' ? 'Antes' : 'Depois'}
                            </div>
                        </div>
                    ))}
                    {/* Mock Comparison */}
                     <div className="relative group rounded-xl overflow-hidden shadow-sm aspect-square bg-slate-100">
                        <img src="https://picsum.photos/400/400?grayscale" alt="Demo Before" className="w-full h-full object-cover" />
                         <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white p-2 text-xs font-bold uppercase backdrop-blur-sm">
                            Exemplo Antes
                        </div>
                    </div>
                     <div className="relative group rounded-xl overflow-hidden shadow-sm aspect-square bg-slate-100">
                        <img src="https://picsum.photos/401/401" alt="Demo After" className="w-full h-full object-cover" />
                         <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white p-2 text-xs font-bold uppercase backdrop-blur-sm">
                            Exemplo Depois
                        </div>
                    </div>
                </div>
            </div>
        )}

        {activeTab === 'payments' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
                {/* Left Column: History & Appointments */}
                <div className="lg:col-span-2 space-y-6">
                    {/* Appointment History */}
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                        <h4 className="font-semibold text-slate-700 mb-3 flex items-center gap-2">
                            <Calendar size={18} className="text-secondary" />
                            Histórico de Agendamentos
                        </h4>
                        <div className="space-y-2 max-h-48 overflow-y-auto">
                            {appointments.map(apt => (
                                <div key={apt.id} className="flex justify-between items-center p-3 bg-white rounded-lg border border-slate-200 shadow-sm">
                                    <div>
                                        <p className="text-sm font-medium text-slate-800">{apt.procedure}</p>
                                        <p className="text-xs text-slate-500">{new Date(apt.date).toLocaleDateString()}</p>
                                    </div>
                                    <span className={`text-xs px-2 py-1 rounded-full font-bold uppercase ${
                                        apt.status === 'completed' ? 'bg-green-100 text-green-700' :
                                        apt.status === 'scheduled' ? 'bg-blue-100 text-blue-700' : 'bg-red-100 text-red-700'
                                    }`}>
                                        {apt.status === 'completed' ? 'Realizado' : apt.status === 'scheduled' ? 'Agendado' : 'Cancelado'}
                                    </span>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Payment History */}
                    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
                        <div className="p-4 border-b border-slate-100 bg-slate-50">
                            <h4 className="font-semibold text-slate-700">Pagamentos Realizados</h4>
                        </div>
                        <table className="w-full text-left">
                            <thead className="bg-slate-50 border-b border-slate-100">
                                <tr>
                                    <th className="p-3 text-xs font-medium text-slate-500 uppercase">Data</th>
                                    <th className="p-3 text-xs font-medium text-slate-500 uppercase">Procedimento</th>
                                    <th className="p-3 text-xs font-medium text-slate-500 uppercase">Valor</th>
                                    <th className="p-3 text-xs font-medium text-slate-500 uppercase text-center">Comp.</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {payments.map(pay => (
                                    <tr key={pay.id} className="hover:bg-slate-50">
                                        <td className="p-3 text-sm text-slate-600">{new Date(pay.date).toLocaleDateString()}</td>
                                        <td className="p-3 text-sm font-medium text-slate-800">{pay.procedure}</td>
                                        <td className="p-3 text-sm font-bold text-green-600">R$ {pay.amount.toFixed(2)}</td>
                                        <td className="p-3 text-center">
                                            {pay.receiptUrl ? (
                                                <a href={pay.receiptUrl} target="_blank" rel="noreferrer" className="text-blue-500 hover:text-blue-700 inline-block">
                                                    <FileText size={16} />
                                                </a>
                                            ) : (
                                                <span className="text-slate-300">-</span>
                                            )}
                                        </td>
                                    </tr>
                                ))}
                                {payments.length === 0 && (
                                    <tr>
                                        <td colSpan={4} className="p-4 text-center text-slate-400 text-sm">Nenhum pagamento registrado.</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* Right Column: New Payment Form */}
                <div className="bg-white p-6 rounded-xl border border-primary/20 shadow-lg shadow-pink-50 h-fit">
                    <h4 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                        <CreditCard className="text-primary" />
                        Novo Pagamento
                    </h4>
                    
                    <form onSubmit={handlePaymentSubmit} className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-slate-600 mb-1">Data do Pagamento</label>
                            <input 
                                type="date"
                                required 
                                value={newPayment.date}
                                onChange={(e) => setNewPayment({...newPayment, date: e.target.value})}
                                className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none text-sm"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-slate-600 mb-1">Procedimento</label>
                            <input 
                                type="text" 
                                required
                                placeholder="Ex: Botox Testa"
                                value={newPayment.procedure}
                                onChange={(e) => setNewPayment({...newPayment, procedure: e.target.value})}
                                className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none text-sm"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-slate-600 mb-1">Valor (R$)</label>
                            <input 
                                type="number" 
                                step="0.01"
                                required
                                placeholder="0,00"
                                value={newPayment.amount || ''}
                                onChange={(e) => setNewPayment({...newPayment, amount: Number(e.target.value)})}
                                className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none text-sm font-bold text-slate-700"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-slate-600 mb-1">Comprovante</label>
                            <div className="flex items-center gap-2">
                                <label className="flex-1 flex items-center justify-center gap-2 p-2 border border-dashed border-slate-300 rounded-lg cursor-pointer hover:bg-slate-50 text-slate-500 text-sm transition-colors">
                                    <Upload size={16} />
                                    {tempReceipt ? 'Alterar Arquivo' : 'Upload Foto/PDF'}
                                    <input type="file" accept="image/*,.pdf" className="hidden" onChange={handleReceiptUpload} />
                                </label>
                                {tempReceipt && (
                                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center text-green-600">
                                        <CheckCircle size={20} />
                                    </div>
                                )}
                            </div>
                        </div>

                        <button 
                            type="submit"
                            className="w-full bg-primary text-white font-bold py-3 rounded-xl hover:bg-pink-700 transition-all shadow-md mt-2 flex items-center justify-center gap-2"
                        >
                            <CheckCircle size={18} />
                            Registrar Pagamento
                        </button>
                    </form>
                </div>
            </div>
        )}
      </div>
    </div>
  );
};