import React from 'react';
import { Product } from '../types';
import { AlertTriangle, TrendingUp, Users, Calendar } from 'lucide-react';

interface DashboardProps {
  products: Product[];
}

export const Dashboard: React.FC<DashboardProps> = ({ products }) => {
  // Logic to find expiring and low stock items
  const today = new Date();
  const nextMonth = new Date();
  nextMonth.setDate(today.getDate() + 30);

  const expiringProducts = products.filter(p => {
    const expiry = new Date(p.expiryDate);
    return expiry > today && expiry <= nextMonth;
  });

  const lowStockProducts = products.filter(p => p.quantity < 5);

  return (
    <div className="space-y-6">
        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-pink-50 text-primary flex items-center justify-center">
                    <TrendingUp size={24} />
                </div>
                <div>
                    <p className="text-sm text-slate-500 font-medium">Faturamento Hoje</p>
                    <h3 className="text-2xl font-bold text-slate-800">R$ 2.450</h3>
                </div>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                 <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center">
                    <Calendar size={24} />
                </div>
                <div>
                    <p className="text-sm text-slate-500 font-medium">Agendamentos</p>
                    <h3 className="text-2xl font-bold text-slate-800">8</h3>
                </div>
            </div>
             <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                 <div className="w-12 h-12 rounded-full bg-green-50 text-green-600 flex items-center justify-center">
                    <Users size={24} />
                </div>
                <div>
                    <p className="text-sm text-slate-500 font-medium">Novos Pacientes</p>
                    <h3 className="text-2xl font-bold text-slate-800">3</h3>
                </div>
            </div>
             <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
                 <div className="w-12 h-12 rounded-full bg-purple-50 text-purple-600 flex items-center justify-center">
                    <AlertTriangle size={24} />
                </div>
                <div>
                    <p className="text-sm text-slate-500 font-medium">Alertas</p>
                    <h3 className="text-2xl font-bold text-slate-800">
                        {expiringProducts.length + lowStockProducts.length}
                    </h3>
                </div>
            </div>
        </div>

        {/* Alerts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <AlertTriangle className="text-amber-500" size={20}/>
                    Lotes Vencendo (30 dias)
                </h3>
                {expiringProducts.length === 0 ? (
                    <p className="text-slate-400 text-sm">Nenhum produto vencendo em breve.</p>
                ) : (
                    <ul className="space-y-3">
                        {expiringProducts.map(p => (
                            <li key={p.id} className="flex justify-between items-center p-3 bg-amber-50 rounded-lg border border-amber-100">
                                <div>
                                    <p className="font-medium text-amber-900 text-sm">{p.name}</p>
                                    <p className="text-xs text-amber-700">Lote: {p.lotNumber}</p>
                                </div>
                                <span className="text-xs font-bold text-amber-800 bg-amber-200 px-2 py-1 rounded">
                                    {new Date(p.expiryDate).toLocaleDateString('pt-BR')}
                                </span>
                            </li>
                        ))}
                    </ul>
                )}
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <AlertTriangle className="text-red-500" size={20}/>
                    Estoque Baixo
                </h3>
                 {lowStockProducts.length === 0 ? (
                    <p className="text-slate-400 text-sm">Estoque saudável.</p>
                ) : (
                    <ul className="space-y-3">
                        {lowStockProducts.map(p => (
                            <li key={p.id} className="flex justify-between items-center p-3 bg-red-50 rounded-lg border border-red-100">
                                <div>
                                    <p className="font-medium text-red-900 text-sm">{p.name}</p>
                                    <p className="text-xs text-red-700">{p.brand}</p>
                                </div>
                                <span className="text-xs font-bold text-red-800 bg-red-200 px-2 py-1 rounded">
                                    Qtd: {p.quantity}
                                </span>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
        </div>
    </div>
  );
};