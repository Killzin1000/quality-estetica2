import React, { useState, useEffect } from 'react';
import { Product } from '../types';
import { Plus, AlertTriangle, Save, Trash2 } from 'lucide-react';

interface StockFormProps {
  products: Product[];
  onAddProduct: (product: Product) => void;
  onDeleteProduct: (id: string) => void;
}

export const StockForm: React.FC<StockFormProps> = ({ products, onAddProduct, onDeleteProduct }) => {
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: '',
    brand: '',
    lotNumber: '',
    expiryDate: '',
    costPrice: 0,
    salePrice: 0,
    supplier: '',
    quantity: 0
  });

  const [margin, setMargin] = useState<{ profit: number; percentage: number }>({ profit: 0, percentage: 0 });

  // Calculate profit margin automatically
  useEffect(() => {
    if (newProduct.costPrice !== undefined && newProduct.salePrice !== undefined) {
      const cost = Number(newProduct.costPrice);
      const sale = Number(newProduct.salePrice);
      const profit = sale - cost;
      const percentage = cost > 0 ? (profit / cost) * 100 : 0;
      
      setMargin({ profit, percentage });
      
      if (cost > 0 || sale > 0) {
        console.log(`[Quality-Log] Calculando lucro: Custo R$${cost} | Venda R$${sale} | Margem: ${percentage.toFixed(2)}%`);
      }
    }
  }, [newProduct.costPrice, newProduct.salePrice]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProduct.name || !newProduct.lotNumber) return;

    const productToAdd: Product = {
      id: crypto.randomUUID(),
      name: newProduct.name!,
      brand: newProduct.brand || '',
      lotNumber: newProduct.lotNumber!,
      expiryDate: newProduct.expiryDate || '',
      costPrice: Number(newProduct.costPrice),
      salePrice: Number(newProduct.salePrice),
      supplier: newProduct.supplier || '',
      quantity: Number(newProduct.quantity)
    };

    console.log('[Quality-Log] Novo produto cadastrado:', productToAdd);
    onAddProduct(productToAdd);
    
    // Reset form
    setNewProduct({
      name: '',
      brand: '',
      lotNumber: '',
      expiryDate: '',
      costPrice: 0,
      salePrice: 0,
      supplier: '',
      quantity: 0
    });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewProduct(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
        <h2 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
          <Plus className="text-primary" />
          Entrada de Estoque
        </h2>

        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-600">Nome do Produto *</label>
            <input
              type="text"
              name="name"
              required
              value={newProduct.name}
              onChange={handleInputChange}
              className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none"
              placeholder="Ex: Toxina Botulínica"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-600">Marca</label>
            <input
              type="text"
              name="brand"
              value={newProduct.brand}
              onChange={handleInputChange}
              className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none"
              placeholder="Ex: Botox"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-600">Fornecedor</label>
            <input
              type="text"
              name="supplier"
              value={newProduct.supplier}
              onChange={handleInputChange}
              className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-600">Lote *</label>
            <input
              type="text"
              name="lotNumber"
              required
              value={newProduct.lotNumber}
              onChange={handleInputChange}
              className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-600">Validade *</label>
            <input
              type="date"
              name="expiryDate"
              required
              value={newProduct.expiryDate}
              onChange={handleInputChange}
              className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none"
            />
          </div>

           <div className="space-y-2">
            <label className="text-sm font-medium text-slate-600">Quantidade</label>
            <input
              type="number"
              name="quantity"
              required
              min="0"
              value={newProduct.quantity}
              onChange={handleInputChange}
              className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-600">Preço de Custo (R$)</label>
            <input
              type="number"
              name="costPrice"
              step="0.01"
              value={newProduct.costPrice}
              onChange={handleInputChange}
              className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-600">Preço de Venda (R$)</label>
            <input
              type="number"
              name="salePrice"
              step="0.01"
              value={newProduct.salePrice}
              onChange={handleInputChange}
              className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none"
            />
          </div>

          <div className="lg:col-span-3 bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="flex gap-6">
                <div>
                    <span className="text-sm text-slate-500 block">Lucro Estimado</span>
                    <span className={`text-lg font-bold ${margin.profit >= 0 ? 'text-green-600' : 'text-red-500'}`}>
                        R$ {margin.profit.toFixed(2)}
                    </span>
                </div>
                <div>
                    <span className="text-sm text-slate-500 block">Margem (%)</span>
                    <span className={`text-lg font-bold ${margin.percentage >= 0 ? 'text-green-600' : 'text-red-500'}`}>
                        {margin.percentage.toFixed(1)}%
                    </span>
                </div>
            </div>
            
            <button
              type="submit"
              className="w-full sm:w-auto px-6 py-2 bg-primary text-white font-medium rounded-lg hover:bg-pink-700 transition-colors flex items-center justify-center gap-2"
            >
              <Save size={18} />
              Cadastrar Produto
            </button>
          </div>
        </form>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50 border-b border-slate-100">
                <tr>
                <th className="p-4 text-sm font-semibold text-slate-600">Produto</th>
                <th className="p-4 text-sm font-semibold text-slate-600">Lote</th>
                <th className="p-4 text-sm font-semibold text-slate-600">Validade</th>
                <th className="p-4 text-sm font-semibold text-slate-600 text-center">Qtd</th>
                <th className="p-4 text-sm font-semibold text-slate-600 text-right">Ações</th>
                </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
                {products.length === 0 ? (
                    <tr>
                        <td colSpan={5} className="p-8 text-center text-slate-400">
                            Nenhum produto cadastrado.
                        </td>
                    </tr>
                ) : (
                    products.map((product) => {
                        const isExpired = new Date(product.expiryDate) < new Date();
                        return (
                            <tr key={product.id} className="hover:bg-slate-50 transition-colors">
                                <td className="p-4">
                                    <div className="font-medium text-slate-800">{product.name}</div>
                                    <div className="text-xs text-slate-500">{product.brand}</div>
                                </td>
                                <td className="p-4 text-slate-600">{product.lotNumber}</td>
                                <td className="p-4">
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${isExpired ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                                        {new Date(product.expiryDate).toLocaleDateString('pt-BR')}
                                    </span>
                                </td>
                                <td className="p-4 text-center font-medium text-slate-700">{product.quantity}</td>
                                <td className="p-4 text-right">
                                    <button 
                                        onClick={() => onDeleteProduct(product.id)}
                                        className="text-slate-400 hover:text-red-500 transition-colors"
                                    >
                                        <Trash2 size={18} />
                                    </button>
                                </td>
                            </tr>
                        )
                    })
                )}
            </tbody>
            </table>
        </div>
      </div>
    </div>
  );
};