export interface Product {
  id: string;
  name: string;
  brand: string;
  lotNumber: string;
  expiryDate: string;
  costPrice: number;
  salePrice: number;
  supplier: string;
  quantity: number;
}

export interface BodyMarker {
  id: string;
  x: number;
  y: number;
  note: string;
  side: 'front' | 'back';
}

export interface Patient {
  id: string;
  name: string;
  age: number;
  phone: string;
  photoUrl?: string;
}

export interface AnamnesisField {
  id: string;
  label: string;
  type: 'text' | 'boolean' | 'select';
  options?: string[];
  value: string | boolean;
}

export interface FinancialRecord {
  id: string;
  description: string;
  amount: number;
  type: 'income' | 'expense';
  date: string;
  category: string;
}

export interface PatientPayment {
  id: string;
  date: string;
  procedure: string;
  amount: number;
  receiptUrl?: string;
}

export interface Appointment {
  id: string;
  date: string;
  procedure: string;
  status: 'completed' | 'scheduled' | 'cancelled';
}

export type ViewState = 'dashboard' | 'patients' | 'stock' | 'financial' | 'calendar';